---
layout:     post
title:      "转载-如何配置docker使用HTTP代理"
subtitle:   ""
description: "如何配置docker使用HTTP代理"
date:       2020-03-10 16:00:00
author:     "朱国毅"
image: "https://img-blog.csdnimg.cn/20190106153342198.png"
published: true
tags:
    - Tips
    - Docker
URL: "/2020/03/10/metalLB/"
categories: [ Tips ]
---