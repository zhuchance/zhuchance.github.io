+++
date = "2020-03-20T12:13:19+08:00"
title = "metalLB"
categories = ["技术文章"]
tags = ["Foo", "Bar"]
toc = true
author = "zhuchance"
author_homepage =  "https://zhuchance.github.io/post/"

+++

## 主题概况

Balalalalala...

Balalalalala...

## 安装指南

1. aaaaaaa
1. bbbbbbb
1. ccccccc

### 安装

**bold**

### 启用


```
print('第一篇!')
```

### 更新

> Blockquotes are very handy in email to emulate reply text.
> This line is part of the same quote.

## 配置指南

| Tables        | Are           | Cool |
| ------------- |:-------------:| -----:|
| col 3 is      | right-aligned | $1600 |
| col 2 is      | centered      |   $12 |
| zebra stripes | are neat      |    $1 |

### 属性

[link text itself]: https://zhuchance.github.io

![qrcode](https://zhuchance.github.io/public/qrcode.jpg)

### 说明

1. First ordered list item
2. Another item
  * Unordered sub-list.
1. Actual numbers don't matter, just that it's a number
  1. Ordered sub-list
4. And another item.

## Q&A

Balabalabalabala...
