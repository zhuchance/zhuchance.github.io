---
title:       "在k8s上部署一个简单的mysql"
subtitle:    "测试环境部署并使用一个单例mysql"
description: "MySQL for Kubernetes"
date:        2020-07-07
author:      "北冥鱼"
image:       "https://labs.mysql.com/common/logos/oracle-logo-red.svg"
tags:        ["K8s", "MySQL"]
categories:  ["Tech" ]
---
### warning 注意MySQL单实例只用于测试环境
``` yaml
##namespace
---
#apiVersion: v1
#kind: Namespace
#metadata:
#  name: pre
##mysql-claim.yaml
---
apiVersion: v1
kind: PersistentVolumeClaim
metadata:
  name: mysql-ex-claim
  namespace: pre-mysql
  annotations:
    volume.beta.kubernetes.io/storage-class: "managed-nfs-storage" 
spec:
  accessModes:
    - ReadWriteOnce
  resources:
    requests:
      storage: 800Gi

##mysql-cm.yaml 
---
apiVersion: v1
kind: ConfigMap
metadata:
  name: mysql-config
  namespace: pre-mysql
data:
  custom.cnf: |
        [mysqld]
        server-id=1
        log-bin
        expire_logs_days=7
        sync_binlog=0
        binlog_cache_size=1M

##mysql-secret.yaml
---
apiVersion: v1
kind: Secret
metadata:
  name: mysql-user-pwd
  namespace: pre-mysql
data:
  #mysql-root-pwd: NXN0YXI=/5star/ZGVtbw==/demo
  mysql-root-pwd: NXN0YXI=
  #mysql-app-user-pwd: NXN0YXI=
  mysql-app-user-pwd: NXN0YXI=
  #mysql-test-user-pwd: NXN0YXI= 
  mysql-test-user-pwd: NXN0YXI=
##mysql-deployment.yaml
---
apiVersion: apps/v1
kind: Deployment
metadata:
  namespace: pre-mysql
  labels:
    app: mysql-ex
  name: mysql-ex
spec:
  replicas: 1
  selector:
    matchLabels:
      app: mysql-ex
  template:
     metadata:
       labels:
         app: mysql-ex
     spec:
       initContainers:
       - name: mysql-init
         image: busybox
         imagePullPolicy: IfNotPresent
         env:
         - name: MYSQL_TEST_USER_PASSWORD
           valueFrom:
             secretKeyRef:
               name: mysql-user-pwd
               key: mysql-test-user-pwd
         command:
           - sh
           - "-c"
           - |
             set -ex
             rm -rf /var/lib/mysql/lost+found
             cat > /docker-entrypoint-initdb.d/mysql-pre-initt.sql <<EOF
             create database mysqlpre default character set utf8;
             grant all on mysqlpre.* to 'test'@'%' identified by '$MYSQL_TEST_USER_PASSWORD';
             flush privileges;
             EOF
             cat > /docker-entrypoint-initdb.d/mysql-appdb-init.sql <<EOF
             create table app(id int);
             insert into app values(1);
             commit;
             EOF
         volumeMounts:
         - name: mysql-data
           mountPath: /var/lib/mysql
         - name: mysql-initdb
           mountPath: /docker-entrypoint-initdb.d
       containers:
       #这边可以更改image: mysql:5.7
         - image: mysql:5.7
           name: mysql
           imagePullPolicy: IfNotPresent
           env:
           - name: MYSQL_ROOT_PASSWORD
             valueFrom:
               secretKeyRef:
                 name: mysql-user-pwd
                 key: mysql-root-pwd
           - name: MYSQL_PASSWORD
             valueFrom:
               secretKeyRef:
                 name: mysql-user-pwd
                 key: mysql-app-user-pwd
           - name: MYSQL_USER
             value: app
           - name: MYSQL_DATABASE
             value: appdb
           volumeMounts:
           - name: mysql-data
             mountPath: /var/lib/mysql
           - name: mysql-initdb
             mountPath: /docker-entrypoint-initdb.d
           - name: mysql-config
             mountPath: /etc/mysql/conf.d/
           ports:
           - name: mysql
             containerPort: 3306
           livenessProbe:
             exec:
               command:
               - /bin/sh
               - "-c"
               - MYSQL_PWD="${MYSQL_ROOT_PASSWORD}"
               - mysql -h 127.0.0.1 -u root -e "SELECT 1"
             initialDelaySeconds: 30
             timeoutSeconds: 5
             successThreshold: 1
             failureThreshold: 3
           readinessProbe:
             exec:
               command:
                 - /bin/sh
                 - "-c"
                 - MYSQL_PWD="${MYSQL_ROOT_PASSWORD}"
                 - mysql -h 127.0.0.1 -u root -e "SELECT 1"
             initialDelaySeconds: 10
             timeoutSeconds: 1
             successThreshold: 1
             failureThreshold: 3
       volumes:
         - name: mysql-data
           persistentVolumeClaim:
             claimName: mysql-ex-claim
         - name: mysql-initdb
           emptyDir: {}
         - name: mysql-config
           configMap:
             name: mysql-config
##services
---
apiVersion: v1
kind: Service
metadata:
  #name: mysql-ex
  name: invoice-application-db
  namespace: pre-mysql
spec:
  selector:
    app: mysql-ex
  ports:
  - port: 3306
    # nodePort: 33016
    protocol: TCP
    port: 3306
    targetPort: 3306
  type: NodePort

```