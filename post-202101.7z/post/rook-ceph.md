---
title:       "rook-ceph-部署篇"
subtitle:    "rook-ceph在k8s集群上安装部署并使用ceph"
description: "Open-Source, Cloud-Native Storages for Kubernetes"
date:        2020-06-28
author:      "北冥鱼"
image:       "https://rook.io/images/index-hero.svg"
tags:        ["K8s", "Storage","Ceph"]
categories:  ["Tech" ]
---
### warning 注意rook-ceph现在还不太建议上生产
#### What is Rook?
  ##### Storage Operators for Kubernetes 引用官网
Rook turns distributed storage systems into self-managing, self-scaling, self-healing storage services. It automates the tasks of a storage administrator: deployment, bootstrapping, configuration, provisioning, scaling, upgrading, migration, disaster recovery, monitoring, and resource management.   
Rook uses the power of the Kubernetes platform to deliver its services via a Kubernetes Operator for each storage provider.

*Rook将分布式存储系统转变为自我管理，自我扩展，自我修复的存储服务。它可以自动执行存储管理员的任务：部署，引导，配置，供应，扩展，升级，迁移，灾难恢复，监视和资源管理。*  
*Rook利用Kubernetes平台的功能通过Kubernetes运营商为每个存储提供商提供服务。*

[rook 官网](https://rook.io)

#### Multiple Storage Providers 提供多种存储类型
>  
> + Ceph
> + EdgeFS
> + CockroachDB
> + Cassandra
> + NFS
> + Yugabyte

Rook orchestrates multiple storage solutions, each with a specialized Kubernetes Operator to automate management. Choose the best storage provider for your scenarios, and Rook ensures that they all run well on Kubernetes with the same, consistent experience.
*Rook精心策划了多个存储解决方案，每个解决方案都配有专门的Kubernetes Operator，以实现自动化管理。为您的方案选择最佳的存储提供商，Rook可以确保它们在Kubernetes上都能以相同，一致的体验很好地运行。*

[github link](https://github.com/rook/rook)

#### Ceph Prerequisites 安装先决条件
> 
> 1. Rook can be installed on any existing Kubernetes cluster as long as it meets the minimum version and Rook is granted the required privileges (see below for more information). If you don’t have a Kubernetes cluster, you can quickly set one up using Minikube, Kubeadm or CoreOS/Vagrant.

> 2. Kubernetes v1.11 or higher is supported by Rook.

> 3. Ceph Prerequisites:
     >> Raw devices (no partitions or formatted filesystems) 原始裸设备没有格式化
     >> Raw partitions (no formatted filesystem) 原始没有格式化文件系统
     >> PVs available from a storage class in block mode 可从存储类以块模式获得的PV
> 4. LVM package
     >> Ceph OSDs have a dependency on LVM in the following scenarios:  下面几种情况需要依赖lvm
     > 1. OSDs are created on raw devices or partitions OSD在原始设备或分区上创建
     > 2. If encryption is enabled (encryptedDevice: true in the cluster CR)如果启用了加密（集群CR中的encryptedDevice：true）
     > 3. A metadata device is specified 指定了元数据设备
LVM is not required for OSDs in these scenarios: 以下情况不需要LVM  
Creating OSDs on PVCs using the storageClassDeviceSets 使用storageClassDeviceSets在PVC上创建OSD  
> 5. Ceph Flexvolume Configuration 配置Flexvolume插件
>> NOTE This configuration is only needed when using the FlexVolume driver (required for Kubernetes 1.12 or earlier). The Ceph-CSI RBD driver or the Ceph-CSI CephFS driver are recommended for Kubernetes 1.13 and newer, making FlexVolume configuration redundant. 这里建议直接使用kubernetes 1.12以上版本然后直接使用Ceph-CSI CephFS driver 

> 6. Kernel 内核版本 建议直接升到4.19
> 7. 裸设备: 服务器上的硬盘不需要分区也无需挂载,如果硬盘里有数据或者分区使用如下命令进行清盘,下面命令也是清理命令
 ```bash
 yum install gdisk -y && sgdisk --zap-all /dev/sd裸设备名  && dd if=/dev/zero of=/dev/sd裸设备名 bs=100M count=100 oflag=direct,dsync && ls /dev/mapper/ceph-* | xargs -I% -- dmsetup remove % && rm -rf /dev/ceph-* && lsblk -f
 ```

#########################################################################################
#### 准备工作完成就可以进行安装rook-ceph了
``` bash
kubectl apply -f https://raw.githubusercontent.com/rook/rook/release-1.3/cluster/examples/kubernetes/ceph/common.yaml
kubectl apply -f https://raw.githubusercontent.com/rook/rook/release-1.3/cluster/examples/kubernetes/ceph/operator.yaml
kubectl apply -f https://raw.githubusercontent.com/rook/rook/release-1.3/cluster/examples/kubernetes/ceph/cluster.yaml
```

等待一会看以下状态，顺利的话到这里就部署完成了

``` bash
[root@master1 ~]# kubectl -n rook-ceph get pod
NAME                                                     READY   STATUS      RESTARTS   AGE
csi-cephfsplugin-cjlx6                                   3/3     Running     0          23h
csi-cephfsplugin-gdxjg                                   3/3     Running     0          23h
csi-cephfsplugin-kglg8                                   3/3     Running     0          23h
csi-cephfsplugin-nrsfn                                   3/3     Running     0          23h
csi-cephfsplugin-provisioner-598854d87f-7q9mh            6/6     Running     0          23h
csi-cephfsplugin-provisioner-598854d87f-b7vgs            6/6     Running     0          23h
csi-cephfsplugin-ztl82                                   3/3     Running     0          23h
csi-rbdplugin-hjvlv                                      3/3     Running     0          23h
csi-rbdplugin-ks488                                      3/3     Running     0          23h
csi-rbdplugin-nzw4r                                      3/3     Running     0          23h
csi-rbdplugin-p5w54                                      3/3     Running     0          23h
csi-rbdplugin-provisioner-dbc67ffdc-kjqh2                6/6     Running     0          23h
csi-rbdplugin-provisioner-dbc67ffdc-nn8dd                6/6     Running     0          23h
csi-rbdplugin-rmrkc                                      3/3     Running     0          23h
rook-ceph-crashcollector-172.20.0.181-54d5b575f7-z7h9f   1/1     Running     0          22h
rook-ceph-crashcollector-172.20.0.182-76c587599d-q22qm   1/1     Running     0          22h
rook-ceph-crashcollector-172.20.0.183-6fd9cd66c5-s8krr   1/1     Running     0          22h
rook-ceph-crashcollector-172.20.0.184-549fcf9496-sp4bl   1/1     Running     0          22h
rook-ceph-crashcollector-172.20.0.185-56678d87d5-fhf8p   1/1     Running     0          23h
rook-ceph-mgr-a-74c8579d58-pr48z                         1/1     Running     0          22h
rook-ceph-mon-a-5fcdbc75dc-h27m7                         1/1     Running     0          23h
rook-ceph-mon-b-689c9c6b5-w5c5z                          1/1     Running     0          23h
rook-ceph-mon-d-6dbf9856f9-27hzg                         1/1     Running     0          22h
rook-ceph-operator-db86d47f5-cm4r6                       1/1     Running     0          23h
rook-ceph-osd-0-84865b865-6kw77                          1/1     Running     0          22h
rook-ceph-osd-1-f4b75cb7c-x6fgp                          1/1     Running     0          22h
rook-ceph-osd-2-596bddd78d-7hnc8                         1/1     Running     0          22h
rook-ceph-osd-3-959f57ccb-mwpfr                          1/1     Running     0          22h
rook-ceph-osd-4-76b457f4cf-6kg5l                         1/1     Running     0          22h
rook-ceph-osd-prepare-172.20.0.181-q8p47                 0/1     Completed   0          4h37m
rook-ceph-osd-prepare-172.20.0.182-2fqc9                 0/1     Completed   0          4h37m
rook-ceph-osd-prepare-172.20.0.183-jqgkc                 0/1     Completed   0          4h37m
rook-ceph-osd-prepare-172.20.0.184-qxvwl                 0/1     Completed   0          4h37m
rook-ceph-osd-prepare-172.20.0.185-d2z98                 0/1     Completed   0          4h37m
rook-ceph-tools-6b4889fdfd-vtqhp                         1/1     Running     0          22h
rook-discover-79vjm                                      1/1     Running     0          23h
rook-discover-s22hb                                      1/1     Running     0          23h
rook-discover-sfntk                                      1/1     Running     0          23h
rook-discover-tflnp                                      1/1     Running     0          23h
rook-discover-tq794                                      1/1     Running     0          23h
```

附上几条有用的命令：
1.查看dashboard的密码：

```bash
~~#kubectl -n rook-ceph get secret rook-ceph-dashboard-password -o yaml | grep "password:" | awk '{print $2}' | base64 --decode~~
~~kubectl -n rook-ceph get secret rook-ceph-dashboard-password -o yaml | grep "password:"|awk '{print $2}' |awk 'NR==1{print}'  | base64 --d~~

kubectl -n rook-ceph get secret rook-ceph-dashboard-password \
-o jsonpath="{['data']['password']}" \
| base64 --decode && echo
```


2.进入ceph工具箱
``` bash
kubectl -n rook-ceph exec -it $(kubectl -n rook-ceph get pod -l "app=rook-ceph-tools" -o jsonpath='{.items[0].metadata.name}') bash
```

#### 测试动态pv

创建storageclass
在源码里面：
code/rook/cluster/examples/kubernetes/ceph/csi/rbd/storageclass.yaml 

通过helm安装：

```bash
helm repo add rook-release https://charts.rook.io/release
 
# Helm 3
helm install --namespace rook-ceph rook-ceph rook-release/rook-ceph
 
# Helm 2
helm install --namespace rook-ceph --name rook-ceph rook-release/rook-ceph
 
 
# 参数示例
helm install --namespace rook-ceph rook-ceph rook-release/rook-ceph \
  --set image.repository=docker.gmem.cc/rook/ceph,logLevel=DEBUG  \
  --set csi.cephcsi.image=docker.gmem.cc/cephcsi/cephcsi:v3.1.0  \
  --set csi.registrar.image=docker.gmem.cc/k8scsi/csi-node-driver-registrar:v1.2.0  \
  --set csi.resizer.image=docker.gmem.cc/k8scsi/csi-resizer:v0.4.0  \
  --set csi.provisioner.image=docker.gmem.cc/k8scsi/csi-provisioner:v1.6.0 \
  --set csi.snapshotter.image=docker.gmem.cc/k8scsi/csi-snapshotter:v2.1.1  \
  --set csi.attacher.image=docker.gmem.cc/k8scsi/csi-attacher:v2.1.0

```





