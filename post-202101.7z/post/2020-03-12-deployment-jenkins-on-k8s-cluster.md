---
title:       "Deployment Jenkins on Kubernetes Cluster"
subtitle:    "在k8s集群里部署Jenkins"
description: "通过部署的Jenkins更新Pod镜像"
date:        2020-03-12
author:      "北冥鱼"
image:       ""
tags:        ["Kubernetes", "Jenkins"]
categories:  ["Tech" ]
---
## Jenkins
### Deployment Jenkins on Kubernetes Cluster

1. deployment jenkins on k8s cluster
   The premise is that there is a load balancing

   在k8s集群里面部署Jenkins，使用load balance暴露服务

``` yaml 
###jenkins-allinone.yaml
###PVC
---
kind: PersistentVolumeClaim
apiVersion: v1
metadata:
  name: jenkins-prd-lb-pvc
  namespace: kube-ops
spec:
  storageClassName: "managed-nfs-storage"
  accessModes:
    - ReadWriteMany
  resources:
    requests:
      storage: 260Gi

###deplayment
---
apiVersion: extensions/v1beta1
kind: Deployment
metadata:
  name: jenkins-prd-lb
  namespace: kube-ops
spec:
  template:
    metadata:
      labels:
        app: jenkins-prd-lb
    spec:
      terminationGracePeriodSeconds: 10
      ###serviceAccountName: jenkins2
      containers:
        - name: jenkins-prd-lb
          image: jenkins/jenkins:lts
          imagePullPolicy: IfNotPresent
          ports:
            - containerPort: 8080
              name: web
              protocol: TCP
            - containerPort: 50000
              name: agent
              protocol: TCP
          resources:
            limits:
              cpu: 2000m
              memory: 4Gi
            requests:
              cpu: 1000m
              memory: 2Gi
          livenessProbe:
            httpGet:
              path: /login
              port: 8080
            initialDelaySeconds: 60
            timeoutSeconds: 5
            failureThreshold: 12
          readinessProbe:
            httpGet:
              path: /login
              port: 8080
            initialDelaySeconds: 60
            timeoutSeconds: 5
            failureThreshold: 12
          volumeMounts:
            - name: jenkinshome
              subPath: jenkins-prd-lb
              mountPath: /var/jenkins_home
          env:
            - name: LIMITS_MEMORY
              valueFrom:
                resourceFieldRef:
                  resource: limits.memory
                  divisor: 1Mi
            - name: JAVA_OPTS
              value: -Xmx$(LIMITS_MEMORY)m -XshowSettings:vm -Dhudson.slaves.NodeProvisioner.initialDelay=0 -Dhudson.slaves.NodeProvisioner.MARGIN=50 -Dhudson.slaves.NodeProvisioner.MARGIN0=0.85 -Duser.timezone=Asia/Shanghai
      securityContext:
        fsGroup: 1000
      volumes:
        - name: jenkinshome
          persistentVolumeClaim:
            claimName: jenkins-prd-lb-pvc
###svc
---
apiVersion: v1
kind: Service
metadata:
  name: jenkins-prd-lb
  namespace: kube-ops
  labels:
    app: jenkins-prd-lb
spec:
  selector:
    app: jenkins-prd-lb
  type: LoadBalancer
  ports:
    - name: web
      port: 8080
      targetPort: web
    - name: agent
      port: 50000
      targetPort: agent

### ingress
#---
#apiVersion: extensions/v1beta1
#kind: Ingress
#metadata:
#  name: jenkins-prd
#  namespace: kube-ops
#  labels:
#    app: jenkins-prd
#spec:
#  rules:
#    - host: devops-pro.com
#      http:
#        paths:
#          - path: /
#            backend:
#              serviceName: jenkins-prd
#              servicePort: 8080

```
2.config jenkins in jenkins dashboard
##
配置好jenkins的kubectl的环境变量

Add  shell script on Jenkins Project

在jenkins项目里面添加构建后执行的shell脚本
```shell
/var/jenkins_home/kubectl -n pre set image deployment/nginx nginx=wordpress

```