---
title:       "Update-Centos8.2-kernel"
subtitle:    "升级centos8的内核"
description: "正确的方式升级centos8.2内核"
date:        2020-08-06
author:      "朱国毅"
image:       ""
tags:        ["Linux", "Kenrel"]
categories:  ["Tech" ]
---
#### 1.查看版本
```bash
cat /etc/redhat-release 
CentOS Linux release 8.2.2004 (Core)
uname -r
4.18.0-193.6.3.el8_2.x86_64
```
#### 2.使用ELRepo仓库
##### 使用ELRepo仓库
```bash
rpm --import https://www.elrepo.org/RPM-GPG-KEY-elrepo.org
```
##### 安装ELRepo仓库的yum源：
```bash
yum --disablerepo="*" --enablerepo="elrepo-kernel" list available
Last metadata expiration check: 3:45:03 ago on Wed 05 Aug 2020 10:16:43 PM EDT.
Available Packages
bpftool.x86_64                                          5.8.0-1.el8.elrepo                        elrepo-kernel
kernel-ml-devel.x86_64                                  5.8.0-1.el8.elrepo                        elrepo-kernel
kernel-ml-doc.noarch                                    5.8.0-1.el8.elrepo                        elrepo-kernel
kernel-ml-headers.x86_64                                5.8.0-1.el8.elrepo                        elrepo-kernel
kernel-ml-modules-extra.x86_64                          5.8.0-1.el8.elrepo                        elrepo-kernel
kernel-ml-tools.x86_64                                  5.8.0-1.el8.elrepo                        elrepo-kernel
kernel-ml-tools-libs.x86_64                             5.8.0-1.el8.elrepo                        elrepo-kernel
kernel-ml-tools-libs-devel.x86_64                       5.8.0-1.el8.elrepo                        elrepo-kernel
perf.x86_64                                             5.8.0-1.el8.elrepo                        elrepo-kernel
python3-perf.x86_64                                     5.8.0-1.el8.elrepo                        elrepo-kernel
```

#### 3.安装最新的内核版本
yum --enablerepo=elrepo-kernel install kernel-ml

设置以新的内核启动
grub2-set-default 0

> centos8中无需再执行grub2-mkconfig -o /boot/grub2/grub.cfg

#### 4.重启
``` bash
reboot
```
#### 5.卸载旧版本内核(可选)
``` bash
rpm -qa | grep kernel
rpm -qa | grep kernel|grep 4.18 |xargs yum remove -y
```
##### 再查看系统已安装的内核，确认旧内核版本已经全部删除：
```  bash
rpm -qa | grep kernel
kernel-ml-modules-5.8.0-1.el8.elrepo.x86_64
kernel-ml-core-5.8.0-1.el8.elrepo.x86_64
kernel-ml-5.8.0-1.el8.elrepo.x86_64
```
也可以安装 yum-utils 工具，当系统安装的内核大于3个时，会自动删除旧的内核版本：
``` bash
dnf install yum-utils
```
#### 6. 花絮与参考文献
说一个搞笑的事情，我的cenots8.2 是安装在vmware esxi虚拟机里面的，当做了如上操作，grub启动的时候引导项也是最新的内核但是启动就是报错，搜索了以下没有发现类似问题，
仔细看了以下报错的信息有 invalid signature，一番搜索后确定是虚拟机里面设置了efi安全启动，关闭以后问题解决。
 > ELRepo官网：http://elrepo.org/tiki/index.php  
 > Centos7升级内核版本：https://www.cnblogs.com/xzkzzz/p/9627658.html  
 > Erics-2020:  https://blog.csdn.net/Thanlon/article/details/107193301  
 > 编译方式安装内核： https://www.cnblogs.com/vincenshen/p/12346829.html  