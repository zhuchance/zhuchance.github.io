---
title:       "上篇-MetalLB 裸金属负载均衡安装与使用"
subtitle:    "MetalLB 安装与使用"
description: "A network load-balancer implementation for Kubernetes using standard routing protocols https://metallb.universe.tf"
date:        2020-03-17
author:      "北冥鱼"
#image:       "https://img-blog.csdnimg.cn/20190106153342198.png0"
categories:  ["Tech" ]
tags:
    - Load Balancer
    - Kubernetes
---


#### metalLB场景和介绍


用来给services暴露IP出来，规划一个集群同网段的IP出来，使用的时候services不能删除，这样方便对接公网的Load balance的nginx，
为了让k8s集群和旧的swarm集群能同时提供服务。
 说一下场景：在实际工作需要中老旧的非容器环境需要和现有的kubernetes环境对接，但kubernetes并没有提供现成的LoadBalancer，常规模式下kubernetes提供的NodePort受限于端口分配效率、Ingress方式L4层不太方便
 查阅了资料找到MetalLB,通过它我们可以达到能像公有云那样接入LoadBalancer。

##### metalLB两个核心
  1. 内部地址分配：
   >+ 使用前需要配置LB(Load Balancer)类型SVC分配IP地址段
  2. 外部地址广播

   >+ Layer2模式使用ARP/NDP广播 
   
   >+ 使用BGP模式

------
[这段内容引用伊布大佬的](https://ieevee.com/tech/2019/06/30/metallb.html#%E5%9C%B0%E5%9D%80%E5%88%86%E9%85%8D "ieevee.com")
###### Layer2 模式
*Layer 2模式下，每个service会有集群中的一个node来负责。当服务客户端发起ARP解析的时候，对应的node会响应该ARP请求，之后，该service的流量都会指向该node（看上去该node上有多个地址）。*
*Layer 2模式并不是真正的负载均衡，因为流量都会先经过1个node后，再通过kube-proxy转给多个end points。如果该node故障，MetalLB会迁移 IP到另一个node，并重新发送免费ARP告知客户端迁移。*
*Layer 2模式更为通用，不需要用户有额外的设备；但由于Layer 2模式使用ARP/ND，地址池分配需要跟客户端在同一子网，地址分配略为繁琐。*

###### BGP模式 

 *BGP模式下，集群中所有node都会跟上联路由器建立BGP连接，并且会告知路由器应该如何转发service的流量，BGP模式是真正的LoadBalancer。*

------

#### MetalLB部署
1. 安装部署相对简单，yaml编排文件主要使用了2个组件

+ metallb-system/controller，负责IP地址的分配，以及service和endpoint的监听的控制器
+ metallb-system/speaker，会在每个节点启动守护进程容器，负责保证service地址可达，例如Layer 2模式下，speaker会负责ARP请求应答

```shell
kubectl apply -f https://raw.githubusercontent.com/google/metallb/v0.8.3/manifests/metallb.yaml
```
2. 配置
> Layer 2 Configuration
```yaml
cat <<EOF | kubectl create -f -
apiVersion: v1
kind: ConfigMap
metadata:
  namespace: metallb-system
  name: config
data:
  config: |
    address-pools:
    - name: default
      protocol: layer2
      addresses:
      - 192.168.1.240-192.168.1.250
EOF
```

> BGP Configuration
``` yaml
cat <<EOF | kubectl create -f -
apiVersion: v1
kind: ConfigMap
metadata:
  namespace: metallb-system
  name: config
data:
  config: |
    peers:
    - peer-address: 10.0.0.1
      peer-asn: 64501
      my-asn: 64500
    address-pools:
    - name: default
      protocol: bgp
      addresses:
      - 192.168.10.0/24
EOF
```

###### 测试
```shell
#创建一个nginx服务，指定服务暴露使用LoadBalancer

cat <<EOF | kubectl create -f -
apiVersion: apps/v1beta2
kind: Deployment
metadata:
  name: nginx
spec:
  selector:
    matchLabels:
      app: nginx
  template:
    metadata:
      labels:
        app: nginx
    spec:
      containers:
      - name: nginx
        image: nginx:1
        ports:
        - name: http
          containerPort: 80

---
apiVersion: v1
kind: Service
metadata:
  name: nginx
spec:
  ports:
  - name: http
    port: 80
    protocol: TCP
    targetPort: 80
  selector:
    app: nginx
  type: LoadBalancer
EOF
```

等服务起来直接访问EXTERNAL-IP就可以实现nginx欢迎界面

**下篇将继续**