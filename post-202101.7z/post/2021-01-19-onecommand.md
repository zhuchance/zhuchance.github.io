---
title:       "OneCommand"
subtitle:    "一条精选的Linux命令"
description: "memory"
date:        2020-09-22
author:      "北冥鱼"
image:       ""
tags:        ["command", "Linux"]
categories:  ["Tech" ]
---

1. MySQL压测：

   

   ``` bash
   #生成数据：
   sysbench /usr/share/sysbench/tests/include/oltp_legacy/oltp.lua --threads=8 --rate=100000  --mysql-user=root --mysql-host=10.20.30.40 --mysql-port=3306 --oltp-test-mode=complex --mysql-db=test  --oltp-tables-count=10 --oltp-table-size=100000 --threads=10 --time=120 --report-interval=10 prepare
   #开始压测：
   sysbench /usr/share/sysbench/tests/include/oltp_legacy/oltp.lua --mysql-host=10.20.30.40 --mysql-port=3306 --mysql-user=root  --oltp-test-mode=complex --mysql-db=test --oltp-tables-count=10 --oltp-table-size=100000 --threads=10 --time=120 --report-interval=10 run >> /home/mysysbench.log
   #删除数据：
   sysbench /usr/share/sysbench/tests/include/oltp_legacy/oltp.lua --mysql-host=10.20.30.40 --mysql-port=3306 --mysql-user=root  --oltp-test-mode=complex --mysql-db=test --oltp-tables-count=10 --oltp-table-size=100000 --threads=10 --time=120 --report-interval=10 cleanup
   ```

2. k8s代理pod端口对外服务：

   ```bash
   kubectl proxy --address='192.168.1.20'  --accept-hosts '.*'  --port=80 --api-prefix=/
   ```

3.  查询k8s dashboard密码：

   ```bash
   # 获取 Bearer Token，找到输出中 ‘token:’ 开头那一行
    kubectl -n kube-system describe secret $(kubectl -n kube-system get secret | grep read-user | awk '{print $1}')
   ```

   

4.  通过cat命令创建serviceaccount

   ```bash
   cat <<EOF | kubectl apply -f -
   apiVersion: v1
   kind: ServiceAccount
   metadata:
     name: admin-user
     namespace: kubernetes-dashboard
   EOF
   ```

   

5.  获取pods和节点的列表,支持的字段选择器因Kubernetes资源类型而异。所有资源类型都支持metadata.name和metadata.namespace字段 找到所有节点未运行的pod（不是running状态的）
   ```bash
   kubectl get pods -A --field-selector=status.phase!=Running | grep -v Complete
   ```

   

6.  找到所有命名空间的所有pod排除ns名为kube-system和kubernetes-dashboard 排除多个ns使用 , 隔开

   ```bash
   kubectl get pod  --all-namespaces --field-selector metadata.namespace!=kube-system,metadata.namespace!=kubernetes-dashboard
   ```


7.  找到所有命名空间的所有pod其状态不是running且重启策略等于Always

   ```bash
   kubectl get pods -A --field-selector=status.phase!=Running,spec.restartPolicy=Always

   ```

   

8.  找到所有命名空间的daemonset控制器,statefulsets控制器及services且命名空间不是default
```bash

kubectl get daemonset,statefulsets,services --all-namespaces --field-selector metadata.namespace!=default
```

9.  获取节点列表及其内存大小的方法

```bash
kubectl get no -o json | \
  jq -r '.items | sort_by(.status.capacity.memory)[]|[.metadata.name,.status.capacity.memory]| @tsv'

```

10. 获取节点列表及其CPU大小的方法
   
```bash
kubectl get no -o json |   jq -r '.items | sort_by(.status.capacity.cpu)[]|[.metadata.name,.status.capacity.cpu]| @tsv'

```

11.    获取节点列表和在其上运行的容器的数量

```bash
kubectl get po -o json --all-namespaces | \
  jq '.items | group_by(.spec.nodeName) | map({"nodeName": .[0].spec.nodeName, "count": length}) | sort_by(.count)'

```

12.  使用kubectl top获取消耗CPU资源的pod列表,使用kubectl top获取消耗内存资源的pod列表
  
```bash
kubectl top pods -A | sort --reverse --key 3 --numeric
kubectl top pods -A | sort --reverse --key 4 --numeric
```
13.  查看所有群集节点的CPU和内存请求和限制
  
```bash
kubectl describe nodes | grep -A 3 "Resource .*Requests .*Limits"

```
14.  获取命名空间中所有pod的labels

  
```bash
for a in $(kubectl get pods -n ailab -o name); do \
  echo -e "\nPod ${a}"; \
  kubectl -n ailab describe ${a} | awk '/Labels:/,/Annotations/' | sed '/Annotations/d'; \
done
```
15.  获取所有namespace,podname,containers
  
```bash
kubectl get pod -A -o=jsonpath='{range .items[*]}{.metadata.namespace},{.metadata.name},{.spec.containers[*].image}{"\n"}' | tr -s ' ' '\n'

```
16.  获取所有HPA（Horizo​​ntal Pod Autoscaler）上的当前副本数
  
```bash
kubectl get hpa -A -o=custom-columns=NAME:.metadata.name,REPLICAS:.status.currentReplicas | sort -k2 -n -r

```
17.  对Pod列表排序（按重启次数排序）  
```bash
kubectl get pods --sort-by=.status.containerStatuses[0].restartCount

```
18.  打印kube-system命名空间下每个pod的限制和请求
  
```bash
kubectl get pods -n kube-system -o=custom-columns='NAME:spec.containers[*].name,MEMREQ:spec.containers[*].resources.requests.memory,MEMLIM:spec.containers[*].resources.limits.memory,CPUREQ:spec.containers[*].resources.requests.cpu,CPULIM:spec.containers[*].resources.limits.cpu'

```
19.  kubectl explain
  
```bash
kubectl explain hpa
kubectl explain hpa.spec.targetCPUUtilizationPercentage
kubectl explain deploy.spec.template.spec.containers.imagePullPolicy
kubectl explain svc.spec.selector

```
20.  获取node节点IP
  
```bash
kubectl get nodes -o json | \
  jq -r '.items[].status.addresses[]? | select (.type == "InternalIP") | .address' | \
  paste -sd "\n" -

```
21. 获取所有群集节点的IP和名称  
  
```bash
kubectl get nodes -o json | grep -A 12 addresses

for n in $(kubectl get nodes -o name); do \
  echo -e "\nNode ${n}"; \
  kubectl get ${n} -o json | grep -A 8 addresses; \
done

```
22.  获取所有服务及其各自的nodePort
  
```bash
kubectl get --all-namespaces svc -o json | \
  jq -r '.items[] | [.metadata.name,([.spec.ports[].nodePort | tostring ] | join("|"))]| @tsv'

```
23.  获取pod子网
  
```bash
kubectl get nodes -o jsonpath='{.items[*].spec.podCIDR}' | tr " " "\n"

```
24.  打印带有时间戳的日志
```bash
kubectl logs -f -n ailab tensorflow-5-25-bb7d8f464-x2x5z --timestamps

```

25.  显示尾部行数
```bash
kubectl logs -f -n ailab tensorflow-5-25-bb7d8f464-x2x5z --tail=10

```

26.  获取上一个容器的日志（例如：如果它已经崩溃）,使用标签过滤

```bash
kubectl logs -f -n default dcgm-exporter-9j48q --previous
kubectl logs -f -n ailab tensorflow-5-25-bb7d8f464-x2x5z --all-containers


```


27.  获取dashboard的登录令牌
```bash
kubectl -n kube-system describe secret $(kubectl -n kube-system get secret | grep read-user | awk '{print $1}')
```


28.  获取kuboard管理员口令
```bash
echo $(kubectl -n kube-system get secret $(kubectl -n kube-system get secret | grep kuboard-user | awk '{print $1}') -o go-template='{{.data.token}}' | base64 -d)  

```


29.  杀掉所有python进程
```bash
ps -ef |  grep python |  grep -v grep |  awk '{print $2}' |  xargs kill -9
```


30.  
```bash

```


31.  
```bash

```


32.  
```bash

```


33.  
```bash

```


34.   
```bash

```


35.  
```bash

```


36.  

37.  

38.  

39.  

40.  

41.  

42.  

43.  

44.  

45.  

46.  

47.  

48.  

49.  

50. 

