---
title:       "helm3 使用国内原安装Weave Scope"
subtitle:    "k8s 周边生态"
description: "helm3 使用国内原安装Weave Scope"
date:        2020-06-01
author:      "北冥鱼"
image:       ""
tags:        ["k8s", "cloud"]
categories:  ["Tech" ]
---

###### Weave Scope是Docker 和Kubernetes 可视化监控工具。 Scope 提供了至上而下的集群基础设施和应用的完整视图，用户可以轻松对分布式的容器化应用进行实时监控和问题诊断。[https://www.weave.works/oss/scope/](https://www.weave.works/oss/scope/)

**1.使用Helm3添加阿里云的源安装它：**

``` shell
helm repo add stable https://kubernetes.oss-cn-hangzhou.aliyuncs.com/charts
 
helm fetch stable/weave-scope
 
tar -zxvf weave-scope-1.1.8.tgz
 
sed -i "s@\ type:\ \"ClusterIP\"@ type: \"NodePort\"@" weave-scope/values.yaml 
#替换成Nodeport模式对外提供服务
 
helm install -n weave-scope --namespace common-service -f weave-scope/values.yaml weave-scope/
```

**2.使用官网提供的k8s资源描述文件yaml安装**
``` shell
apiVersion: v1
kind: List
items:
  - apiVersion: v1
    kind: Namespace
    metadata:
      name: weave
      annotations:
        cloud.weave.works/version: v1.0.0-269-gffdc830
  - apiVersion: v1
    kind: ServiceAccount
    metadata:
      name: weave-scope
      annotations:
        cloud.weave.works/launcher-info: |-
          {
            "original-request": {
              "url": "/k8s/scope.yaml?k8s-version=Q2xpZW50IFZlcnNpb246IHZlcnNpb24uSW5mb3tNYWpvcjoiMSIsIE1pbm9yOiIxNiIsIEdpdFZlcnNpb246InYxLjE2LjYiLCBHaXRDb21taXQ6IjcyYzMwMTY2YjIxMDVjZDdkMzM1MGYyYzI4YTIxOWU2YWJjZDc5ZWIiLCBHaXRUcmVlU3RhdGU6ImNsZWFuIiwgQnVpbGREYXRlOiIyMDIwLTAxLTE4VDIzOjMxOjMxWiIsIEdvVmVyc2lvbjoiZ28xLjEzLjUiLCBDb21waWxlcjoiZ2MiLCBQbGF0Zm9ybToibGludXgvYW1kNjQifQpTZXJ2ZXIgVmVyc2lvbjogdmVyc2lvbi5JbmZve01ham9yOiIxIiwgTWlub3I6IjE2IiwgR2l0VmVyc2lvbjoidjEuMTYuNiIsIEdpdENvbW1pdDoiNzJjMzAxNjZiMjEwNWNkN2QzMzUwZjJjMjhhMjE5ZTZhYmNkNzllYiIsIEdpdFRyZWVTdGF0ZToiY2xlYW4iLCBCdWlsZERhdGU6IjIwMjAtMDEtMThUMjM6MjM6MjFaIiwgR29WZXJzaW9uOiJnbzEuMTMuNSIsIENvbXBpbGVyOiJnYyIsIFBsYXRmb3JtOiJsaW51eC9hbWQ2NCJ9Cg==[",
              "date": "Thu May 21 2020 02:39:27 GMT+0000 (UTC)"
            },
            "email-address": "support@weave.works"
          }
      labels:
        name: weave-scope
      namespace: weave
  - apiVersion: rbac.authorization.k8s.io/v1
    kind: ClusterRole
    metadata:
      name: weave-scope
      annotations:
        cloud.weave.works/launcher-info: |-
          {
            "original-request": {
              "url": "/k8s/scope.yaml?k8s-version=Q2xpZW50IFZlcnNpb246IHZlcnNpb24uSW5mb3tNYWpvcjoiMSIsIE1pbm9yOiIxNiIsIEdpdFZlcnNpb246InYxLjE2LjYiLCBHaXRDb21taXQ6IjcyYzMwMTY2YjIxMDVjZDdkMzM1MGYyYzI4YTIxOWU2YWJjZDc5ZWIiLCBHaXRUcmVlU3RhdGU6ImNsZWFuIiwgQnVpbGREYXRlOiIyMDIwLTAxLTE4VDIzOjMxOjMxWiIsIEdvVmVyc2lvbjoiZ28xLjEzLjUiLCBDb21waWxlcjoiZ2MiLCBQbGF0Zm9ybToibGludXgvYW1kNjQifQpTZXJ2ZXIgVmVyc2lvbjogdmVyc2lvbi5JbmZve01ham9yOiIxIiwgTWlub3I6IjE2IiwgR2l0VmVyc2lvbjoidjEuMTYuNiIsIEdpdENvbW1pdDoiNzJjMzAxNjZiMjEwNWNkN2QzMzUwZjJjMjhhMjE5ZTZhYmNkNzllYiIsIEdpdFRyZWVTdGF0ZToiY2xlYW4iLCBCdWlsZERhdGU6IjIwMjAtMDEtMThUMjM6MjM6MjFaIiwgR29WZXJzaW9uOiJnbzEuMTMuNSIsIENvbXBpbGVyOiJnYyIsIFBsYXRmb3JtOiJsaW51eC9hbWQ2NCJ9Cg==[",
              "date": "Thu May 21 2020 02:39:27 GMT+0000 (UTC)"
            },
            "email-address": "support@weave.works"
          }
      labels:
        name: weave-scope
    rules:
      - apiGroups:
          - ''
        resources:
          - pods
        verbs:
          - get
          - list
          - watch
          - delete
      - apiGroups:
          - ''
        resources:
          - pods/log
          - services
          - nodes
          - namespaces
          - persistentvolumes
          - persistentvolumeclaims
        verbs:
          - get
          - list
          - watch
      - apiGroups:
          - apps
        resources:
          - deployments
          - daemonsets
          - statefulsets
        verbs:
          - get
          - list
          - watch
      - apiGroups:
          - batch
        resources:
          - cronjobs
          - jobs
        verbs:
          - get
          - list
          - watch
      - apiGroups:
          - extensions
        resources:
          - deployments
          - daemonsets
        verbs:
          - get
          - list
          - watch
      - apiGroups:
          - apps
        resources:
          - deployments/scale
        verbs:
          - get
          - update
      - apiGroups:
          - extensions
        resources:
          - deployments/scale
        verbs:
          - get
          - update
      - apiGroups:
          - storage.k8s.io
        resources:
          - storageclasses
        verbs:
          - get
          - list
          - watch
      - apiGroups:
          - volumesnapshot.external-storage.k8s.io
        resources:
          - volumesnapshots
          - volumesnapshotdatas
        verbs:
          - list
          - watch
  - apiVersion: rbac.authorization.k8s.io/v1
    kind: ClusterRoleBinding
    metadata:
      name: weave-scope
      annotations:
        cloud.weave.works/launcher-info: |-
          {
            "original-request": {
              "url": "/k8s/scope.yaml?k8s-version=Q2xpZW50IFZlcnNpb246IHZlcnNpb24uSW5mb3tNYWpvcjoiMSIsIE1pbm9yOiIxNiIsIEdpdFZlcnNpb246InYxLjE2LjYiLCBHaXRDb21taXQ6IjcyYzMwMTY2YjIxMDVjZDdkMzM1MGYyYzI4YTIxOWU2YWJjZDc5ZWIiLCBHaXRUcmVlU3RhdGU6ImNsZWFuIiwgQnVpbGREYXRlOiIyMDIwLTAxLTE4VDIzOjMxOjMxWiIsIEdvVmVyc2lvbjoiZ28xLjEzLjUiLCBDb21waWxlcjoiZ2MiLCBQbGF0Zm9ybToibGludXgvYW1kNjQifQpTZXJ2ZXIgVmVyc2lvbjogdmVyc2lvbi5JbmZve01ham9yOiIxIiwgTWlub3I6IjE2IiwgR2l0VmVyc2lvbjoidjEuMTYuNiIsIEdpdENvbW1pdDoiNzJjMzAxNjZiMjEwNWNkN2QzMzUwZjJjMjhhMjE5ZTZhYmNkNzllYiIsIEdpdFRyZWVTdGF0ZToiY2xlYW4iLCBCdWlsZERhdGU6IjIwMjAtMDEtMThUMjM6MjM6MjFaIiwgR29WZXJzaW9uOiJnbzEuMTMuNSIsIENvbXBpbGVyOiJnYyIsIFBsYXRmb3JtOiJsaW51eC9hbWQ2NCJ9Cg==[",
              "date": "Thu May 21 2020 02:39:27 GMT+0000 (UTC)"
            },
            "email-address": "support@weave.works"
          }
      labels:
        name: weave-scope
    roleRef:
      kind: ClusterRole
      name: weave-scope
      apiGroup: rbac.authorization.k8s.io
    subjects:
      - kind: ServiceAccount
        name: weave-scope
        namespace: weave
  - apiVersion: apps/v1
    kind: Deployment
    metadata:
      name: weave-scope-app
      annotations:
        cloud.weave.works/launcher-info: |-
          {
            "original-request": {
              "url": "/k8s/scope.yaml?k8s-version=Q2xpZW50IFZlcnNpb246IHZlcnNpb24uSW5mb3tNYWpvcjoiMSIsIE1pbm9yOiIxNiIsIEdpdFZlcnNpb246InYxLjE2LjYiLCBHaXRDb21taXQ6IjcyYzMwMTY2YjIxMDVjZDdkMzM1MGYyYzI4YTIxOWU2YWJjZDc5ZWIiLCBHaXRUcmVlU3RhdGU6ImNsZWFuIiwgQnVpbGREYXRlOiIyMDIwLTAxLTE4VDIzOjMxOjMxWiIsIEdvVmVyc2lvbjoiZ28xLjEzLjUiLCBDb21waWxlcjoiZ2MiLCBQbGF0Zm9ybToibGludXgvYW1kNjQifQpTZXJ2ZXIgVmVyc2lvbjogdmVyc2lvbi5JbmZve01ham9yOiIxIiwgTWlub3I6IjE2IiwgR2l0VmVyc2lvbjoidjEuMTYuNiIsIEdpdENvbW1pdDoiNzJjMzAxNjZiMjEwNWNkN2QzMzUwZjJjMjhhMjE5ZTZhYmNkNzllYiIsIEdpdFRyZWVTdGF0ZToiY2xlYW4iLCBCdWlsZERhdGU6IjIwMjAtMDEtMThUMjM6MjM6MjFaIiwgR29WZXJzaW9uOiJnbzEuMTMuNSIsIENvbXBpbGVyOiJnYyIsIFBsYXRmb3JtOiJsaW51eC9hbWQ2NCJ9Cg==[",
              "date": "Thu May 21 2020 02:39:27 GMT+0000 (UTC)"
            },
            "email-address": "support@weave.works"
          }
      labels:
        name: weave-scope-app
        app: weave-scope
        weave-cloud-component: scope
        weave-scope-component: app
      namespace: weave
    spec:
      replicas: 1
      revisionHistoryLimit: 2
      selector:
        matchLabels:
          name: weave-scope-app
          app: weave-scope
          weave-cloud-component: scope
          weave-scope-component: app
      template:
        metadata:
          labels:
            name: weave-scope-app
            app: weave-scope
            weave-cloud-component: scope
            weave-scope-component: app
        spec:
          containers:
            - name: app
              args:
                - '--mode=app'
              command:
                - /home/weave/scope
              env: []
              image: 'docker.io/weaveworks/scope:1.13.1'
              imagePullPolicy: IfNotPresent
              ports:
                - containerPort: 4040
                  protocol: TCP
  - apiVersion: v1
    kind: Service
    metadata:
      name: weave-scope-app
      annotations:
        cloud.weave.works/launcher-info: |-
          {
            "original-request": {
              "url": "/k8s/scope.yaml?k8s-version=Q2xpZW50IFZlcnNpb246IHZlcnNpb24uSW5mb3tNYWpvcjoiMSIsIE1pbm9yOiIxNiIsIEdpdFZlcnNpb246InYxLjE2LjYiLCBHaXRDb21taXQ6IjcyYzMwMTY2YjIxMDVjZDdkMzM1MGYyYzI4YTIxOWU2YWJjZDc5ZWIiLCBHaXRUcmVlU3RhdGU6ImNsZWFuIiwgQnVpbGREYXRlOiIyMDIwLTAxLTE4VDIzOjMxOjMxWiIsIEdvVmVyc2lvbjoiZ28xLjEzLjUiLCBDb21waWxlcjoiZ2MiLCBQbGF0Zm9ybToibGludXgvYW1kNjQifQpTZXJ2ZXIgVmVyc2lvbjogdmVyc2lvbi5JbmZve01ham9yOiIxIiwgTWlub3I6IjE2IiwgR2l0VmVyc2lvbjoidjEuMTYuNiIsIEdpdENvbW1pdDoiNzJjMzAxNjZiMjEwNWNkN2QzMzUwZjJjMjhhMjE5ZTZhYmNkNzllYiIsIEdpdFRyZWVTdGF0ZToiY2xlYW4iLCBCdWlsZERhdGU6IjIwMjAtMDEtMThUMjM6MjM6MjFaIiwgR29WZXJzaW9uOiJnbzEuMTMuNSIsIENvbXBpbGVyOiJnYyIsIFBsYXRmb3JtOiJsaW51eC9hbWQ2NCJ9Cg==[",
              "date": "Thu May 21 2020 02:39:27 GMT+0000 (UTC)"
            },
            "email-address": "support@weave.works"
          }
      labels:
        name: weave-scope-app
        app: weave-scope
        weave-cloud-component: scope
        weave-scope-component: app
      namespace: weave
    spec:
      # type: LoadBalancer
      type: NodePort
      ports:
        - name: app
          port: 80
          protocol: TCP
          targetPort: 4040
      selector:
        name: weave-scope-app
        app: weave-scope
        weave-cloud-component: scope
        weave-scope-component: app
  - apiVersion: apps/v1
    kind: Deployment
    metadata:
      name: weave-scope-cluster-agent
      annotations:
        cloud.weave.works/launcher-info: |-
          {
            "original-request": {
              "url": "/k8s/scope.yaml?k8s-version=Q2xpZW50IFZlcnNpb246IHZlcnNpb24uSW5mb3tNYWpvcjoiMSIsIE1pbm9yOiIxNiIsIEdpdFZlcnNpb246InYxLjE2LjYiLCBHaXRDb21taXQ6IjcyYzMwMTY2YjIxMDVjZDdkMzM1MGYyYzI4YTIxOWU2YWJjZDc5ZWIiLCBHaXRUcmVlU3RhdGU6ImNsZWFuIiwgQnVpbGREYXRlOiIyMDIwLTAxLTE4VDIzOjMxOjMxWiIsIEdvVmVyc2lvbjoiZ28xLjEzLjUiLCBDb21waWxlcjoiZ2MiLCBQbGF0Zm9ybToibGludXgvYW1kNjQifQpTZXJ2ZXIgVmVyc2lvbjogdmVyc2lvbi5JbmZve01ham9yOiIxIiwgTWlub3I6IjE2IiwgR2l0VmVyc2lvbjoidjEuMTYuNiIsIEdpdENvbW1pdDoiNzJjMzAxNjZiMjEwNWNkN2QzMzUwZjJjMjhhMjE5ZTZhYmNkNzllYiIsIEdpdFRyZWVTdGF0ZToiY2xlYW4iLCBCdWlsZERhdGU6IjIwMjAtMDEtMThUMjM6MjM6MjFaIiwgR29WZXJzaW9uOiJnbzEuMTMuNSIsIENvbXBpbGVyOiJnYyIsIFBsYXRmb3JtOiJsaW51eC9hbWQ2NCJ9Cg==[",
              "date": "Thu May 21 2020 02:39:27 GMT+0000 (UTC)"
            },
            "email-address": "support@weave.works"
          }
      labels:
        name: weave-scope-cluster-agent
        app: weave-scope
        weave-cloud-component: scope
        weave-scope-component: cluster-agent
      namespace: weave
    spec:
      replicas: 1
      revisionHistoryLimit: 2
      selector:
        matchLabels:
          name: weave-scope-cluster-agent
          app: weave-scope
          weave-cloud-component: scope
          weave-scope-component: cluster-agent
      template:
        metadata:
          labels:
            name: weave-scope-cluster-agent
            app: weave-scope
            weave-cloud-component: scope
            weave-scope-component: cluster-agent
        spec:
          containers:
            - name: scope-cluster-agent
              args:
                - '--mode=probe'
                - '--probe-only'
                - '--probe.kubernetes.role=cluster'
                - '--probe.http.listen=:4041'
                - '--probe.publish.interval=4500ms'
                - '--probe.spy.interval=2s'
                - 'weave-scope-app.weave.svc.cluster.local:80'
              command:
                - /home/weave/scope
              env: []
              image: 'docker.io/weaveworks/scope:1.13.1'
              imagePullPolicy: IfNotPresent
              ports:
                - containerPort: 4041
                  protocol: TCP
              resources:
                requests:
                  cpu: 25m
                  memory: 80Mi
          serviceAccountName: weave-scope
  - apiVersion: apps/v1
    kind: DaemonSet
    metadata:
      name: weave-scope-agent
      annotations:
        cloud.weave.works/launcher-info: |-
          {
            "original-request": {
              "url": "/k8s/scope.yaml?k8s-version=Q2xpZW50IFZlcnNpb246IHZlcnNpb24uSW5mb3tNYWpvcjoiMSIsIE1pbm9yOiIxNiIsIEdpdFZlcnNpb246InYxLjE2LjYiLCBHaXRDb21taXQ6IjcyYzMwMTY2YjIxMDVjZDdkMzM1MGYyYzI4YTIxOWU2YWJjZDc5ZWIiLCBHaXRUcmVlU3RhdGU6ImNsZWFuIiwgQnVpbGREYXRlOiIyMDIwLTAxLTE4VDIzOjMxOjMxWiIsIEdvVmVyc2lvbjoiZ28xLjEzLjUiLCBDb21waWxlcjoiZ2MiLCBQbGF0Zm9ybToibGludXgvYW1kNjQifQpTZXJ2ZXIgVmVyc2lvbjogdmVyc2lvbi5JbmZve01ham9yOiIxIiwgTWlub3I6IjE2IiwgR2l0VmVyc2lvbjoidjEuMTYuNiIsIEdpdENvbW1pdDoiNzJjMzAxNjZiMjEwNWNkN2QzMzUwZjJjMjhhMjE5ZTZhYmNkNzllYiIsIEdpdFRyZWVTdGF0ZToiY2xlYW4iLCBCdWlsZERhdGU6IjIwMjAtMDEtMThUMjM6MjM6MjFaIiwgR29WZXJzaW9uOiJnbzEuMTMuNSIsIENvbXBpbGVyOiJnYyIsIFBsYXRmb3JtOiJsaW51eC9hbWQ2NCJ9Cg==[",
              "date": "Thu May 21 2020 02:39:27 GMT+0000 (UTC)"
            },
            "email-address": "support@weave.works"
          }
      labels:
        name: weave-scope-agent
        app: weave-scope
        weave-cloud-component: scope
        weave-scope-component: agent
      namespace: weave
    spec:
      minReadySeconds: 5
      selector:
        matchLabels:
          name: weave-scope-agent
          app: weave-scope
          weave-cloud-component: scope
          weave-scope-component: agent
      template:
        metadata:
          labels:
            name: weave-scope-agent
            app: weave-scope
            weave-cloud-component: scope
            weave-scope-component: agent
        spec:
          containers:
            - name: scope-agent
              args:
                - '--mode=probe'
                - '--probe-only'
                - '--probe.kubernetes.role=host'
                - '--probe.publish.interval=4500ms'
                - '--probe.spy.interval=2s'
                - '--probe.docker.bridge=docker0'
                - '--probe.docker=true'
                - 'weave-scope-app.weave.svc.cluster.local:80'
              command:
                - /home/weave/scope
              env: []
              image: 'docker.io/weaveworks/scope:1.13.1'
              imagePullPolicy: IfNotPresent
              resources:
                requests:
                  cpu: 100m
                  memory: 100Mi
              securityContext:
                privileged: true
              volumeMounts:
                - name: scope-plugins
                  mountPath: /var/run/scope/plugins
                - name: sys-kernel-debug
                  mountPath: /sys/kernel/debug
                - name: docker-socket
                  mountPath: /var/run/docker.sock
          dnsPolicy: ClusterFirstWithHostNet
          hostNetwork: true
          hostPID: true
          tolerations:
            - effect: NoSchedule
              operator: Exists
            - effect: NoExecute
              operator: Exists
          volumes:
            - name: scope-plugins
              hostPath:
                path: /var/run/scope/plugins
            - name: sys-kernel-debug
              hostPath:
                path: /sys/kernel/debug
            - name: docker-socket
              hostPath:
                path: /var/run/docker.sock
      updateStrategy:
        type: RollingUpdate

```

查看对外服务地址，通过浏览器访问即可。这里scope有一个问题就是界面没有做登录验证权限管理，这样的话如果能访问scope服务就能做许多操作了。
