---
title:       "强制删除k8s上Terminating的Namespaces"
subtitle:    "这是一篇没有技术含量的文档纯属记录归档k8s维护技巧"
description: "Delete Kubernetes Terminating Namespaces"
date:        2020-07-08
author:      "北冥鱼"
image:       "https://kubernetes.io/images/nav_logo.svg"
tags:        ["K8s", "shell", "memory"]
categories:  ["Tech" ]
---
[转载来自](https://www.cnblogs.com/futuretea/p/11995725.html)
###### 直接复制一个shell脚本吧
``` shell
#!/bin/bash
set -e

useage(){
    echo "useage:"
    echo "  delns.sh NAMESPACE"
}

if [ $# -lt 1 ];then
    useage
    exit
fi

NAMESPACE=$1
JSONFILE=${NAMESPACE}.json
kubectl get ns "${NAMESPACE}" -o json > "${JSONFILE}"
vi "${JSONFILE}"
curl -k -H "Content-Type: application/json" -X PUT --data-binary @"${JSONFLE}" \
    http://127.0.0.1:8001/api/v1/namespaces/"${NAMESPACE}"/finalize


```

使用的时候打开api-server

```shell
kubectl proxy

```
脚本目前是半自动比如要删除的是 kubernetes这个namespace,等脚本打开了vi编辑器再删掉引号重的namespace(kubernetes)保存即可
```shell
"spec": {
        "finalizers": [
            "kubernetes"
        ]
    },
```

#### 再附加一段内容使用etcdctl删除的方法,未经验证

```
# 删除POD
kubectl delete pod PODNAME --force --grace-period=0

# 删除NAMESPACE
kubectl delete namespace NAMESPACENAME --force --grace-period=0
# 实际上验证过无法删除
```
如果以上方法无法删除可以使用如下方法再重试:
```
# 删除default namespace下的pod名为pod-to-be-deleted-0
ETCDCTL_API=3 etcdctl del /registry/pods/default/pod-to-be-deleted-0

# 删除需要删除的NAMESPACE
etcdctl del /registry/namespaces/NAMESPACENAME
```