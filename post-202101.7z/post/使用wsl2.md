---
title:       "window10使用WSL2开启Ubuntu20.04"
subtitle:    "win10 "
description: "window10使用WSL2开启Ubuntu20.04"
date:        2020-09-14
author:      "北冥鱼"
image:       ""
tags:        ["win10", "linux"]
categories:  ["Tech" ]
---

### 食用方式：
1. windows10 开启hyperV和Window Subsystem for Linux 服务并重启，然后在商店搜索Ubuntu并安装之
2. 绿色安装方法： (下载wsl的appx镜像)[https://docs.microsoft.com/zh-cn/windows/wsl/install-manual]，比如下载的Ubuntu 18.04 解压后双击exe可执行文件即可
3. 转换到wsl2： wsl --set-version $(Ubuntu2004)> 2 ，$(Ubuntu2004)用命令：wsl -l -v查看. 或者用wsl --set-default-version 2 设置后面安装的wsl都是2
4. 启动ssh服务：这个是大坑下面单独写；
``` powershell
ubuntu2004 config --default-user root  #设置ubuntu登录默认用户为root，这里本人的子系统名字是ubuntu，有的子系统是ubuntu1804
新建记事本命名为ubuntuSsh.bat 内容填入D:\ubuntu\ubuntu2004 -c "service ssh start"
把ubuntuSsh.bat，放到
C:\Users\用户名\AppData\Roaming\Microsoft\Windows\Start Menu\Programs\Startup文件夹下
```


